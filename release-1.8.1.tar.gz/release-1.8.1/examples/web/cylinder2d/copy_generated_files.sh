#!/usr/bin/env sh

mkdir -p widget/js/generated/
cp cylinder2d.js widget/js/generated/cylinder2d.js
cp cylinder2d.wasm widget/js/generated/cylinder2d.wasm
